import { BrowserRouter, Routes, Route } from "react-router-dom";
import Landing from "./pages/Landing";
import DashboardHome from "./pages/DashboardHome";
import ClimateIntelligence from "./pages/ClimateIntelligence";
import DisasterPrediction from "./pages/DisasterPrediction";
import AirQuality from "./pages/AirQuality";
import WaterSecurity from "./pages/WaterSecurity";
import Forest from "./pages/Forest";
import RenewableEnergy from "./pages/RenewableEnergy";
import CarbonFootprint from "./pages/CarbonFootprint";
import SmartAgriculture from "./pages/SmartAgriculture";
import Ocean from "./pages/Ocean";
import RiskScanner from "./pages/RiskScanner";
import SmartCities from "./pages/SmartCities";
import LearningHub from "./pages/LearningHub";
import Volunteer from "./pages/Volunteer";
import Research from "./pages/Research";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/dashboard" element={<DashboardHome />} />
        <Route path="/climate" element={<ClimateIntelligence />} />
        <Route path="/disasters" element={<DisasterPrediction />} />
        <Route path="/air-quality" element={<AirQuality />} />
        <Route path="/water" element={<WaterSecurity />} />
        <Route path="/forest" element={<Forest />} />
        <Route path="/energy" element={<RenewableEnergy />} />
        <Route path="/carbon" element={<CarbonFootprint />} />
        <Route path="/agriculture" element={<SmartAgriculture />} />
        <Route path="/ocean" element={<Ocean />} />
        <Route path="/risk-scanner" element={<RiskScanner />} />
        <Route path="/cities" element={<SmartCities />} />
        <Route path="/learning" element={<LearningHub />} />
        <Route path="/volunteer" element={<Volunteer />} />
        <Route path="/research" element={<Research />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
